# Checklist para publicar no GitHub

1. Crie um repositório com um nome como `jogo-de-plataforma-construct3`.
2. Coloque o `README.md` na raiz do repositório.
3. Antes de deixar o repositório público, revise/substitua recursos de terceiros.
4. Adicione imagens do jogo em uma pasta `imagens/`.
5. Adicione um vídeo ou link para uma versão publicada, se tiver.
6. Faça o upload do arquivo `.c3p` somente se quiser disponibilizar o projeto para download/edição.
7. No LinkedIn, apresente o projeto com imagens ou vídeo e coloque o link do repositório.
