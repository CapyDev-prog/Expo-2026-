# Jogo de Plataforma

Projeto de jogo de plataforma desenvolvido no **Construct 3**.

## Sobre o projeto

O projeto contém uma estrutura de jogo com menu principal, duas fases, tela de vitória e tela de derrota.

### Estrutura identificada

- **Menu**
- **Fase 1**
- **Fase 2**
- **Vitória**
- **Derrota**

O projeto também possui folhas de eventos separadas para essas telas, além de objetos para personagem, plataformas, itens coletáveis, botões e cenários.

## Tecnologias e recursos

- Construct 3
- JavaScript/engine de eventos do Construct 3
- Sistema de plataforma
- Teclado e mouse
- Áudio
- Sprites e animações
- Colisão e objetos sólidos
- Câmera/centralização no personagem

## Arquivo do projeto

O arquivo `Jogo de plataforma.c3p` é o projeto original do Construct 3.

Para editar o projeto, abra-o no Construct 3.

## Demonstração

Recomenda-se adicionar aqui:
- capturas de tela das fases;
- um vídeo curto mostrando o jogo funcionando;
- um link para uma versão publicada, caso exista.

## Sobre a publicação no GitHub

Antes de tornar o repositório público, revise os recursos utilizados no projeto. O arquivo original contém referências a personagens e músicas de terceiros. Para um portfólio público, é recomendável substituir esses materiais por recursos próprios ou devidamente licenciados.

## Objetivo do projeto

Este projeto pode ser apresentado como prática de desenvolvimento de jogos, lógica de programação, criação de interfaces, organização de eventos e implementação de mecânicas de plataforma.
